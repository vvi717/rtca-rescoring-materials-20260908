# Anonymous prediction-rescoring supplement

Companion to **Readout Fitting for Low-Data Turn-Taking Preference Prediction**.

This small package lets readers recompute the common-split results from saved model predictions and separately obtained public vote counts. It does not retrain encoders, refit calibrators, reproduce model selection independently, or provide an independent test set. The initial full-120-training-dialogue diagnostic (Table 1 and its prior/permutation controls) is outside the executable scope of this package. No incomplete lower-learning-rate predictions are included.

## Run

Use Python 3.10+ and NumPy. No GPU, PyTorch, model download, authentication or project-specific paths are required.

```sh
python -m pip install -r requirements.txt
python score.py --fetch --output rescored.json
```

The second command reads 12 public annotation files from the fixed URLs in `sources.json`, verifies their SHA-256 hashes, and keeps their contents in memory only. It does not upload anything. If the source is unavailable or access changes, obtain the same revision through the original provider and use:

```sh
python score.py --data-dir /path/to/duplexgen-corpus --output rescored.json
```

The directory must contain `annotations/TEA/train.jsonl`, `annotations/TEA/test.jsonl`, and corresponding files for PLN, INT, NEG, PER and SOC. The script refuses to replace an existing output. Use a new filename when running again.

The script checks all 420 dialogue assignments and all 3244 test positions, then compares recomputed results against `expected_results.json` with absolute tolerance `5e-12`. Network acquisition usually dominates runtime; scoring uses CPU and should finish within a few minutes on an ordinary workstation. A PASS means saved-prediction scores agree, not that training or scientific generalization has been independently verified.

## Contents and alignment

- `sources.json`: public dataset revision `3bbe7bc701fee64ecd14a12432e8482c68f8fb85`, original URLs, byte counts and hashes. Source corpus licenses remain applicable; consult the original dataset documentation. This package redistributes neither annotation text nor vote labels.
- `split_manifest.csv`: one row per dialogue, with a hashed identifier, scenario, released partition, analysis partition and number of positions. It contains 96 fit, 24 validation and 300 exposed test dialogues. For the earlier first diagnostic, all 120 released training dialogues were used.
- `positions.csv`: prediction row alignment by hashed dialogue identifier, zero-based history-turn index and zero-based whitespace word index. No dialogue text or original identifier strings are included.
- `predictions.npz`: only model probabilities (`q`), model names and seed identifiers; load with `allow_pickle=False`. Shape is `(3244 positions, 28 outputs, 3 seed positions, 3 actions)`. Action order is `silent`, `backchannel`, `take_floor`. Deterministic structure, scenario and frozen-readout predictions are repeated across seed positions for alignment; these copies are not independent runs.
- `score.py`: standalone target reconstruction, alignment validation, KL/Brier scoring and bootstrap intervals.
- `expected_results.json`: saved means, per-seed results and nine prespecified sensitivity contrasts. The calibration choices are reported for context, not recomputed by this script.
- `FILES_SHA256.json`: archive-file integrity checks.

Dialogue identifiers are SHA-256 of UTF-8 `RTCA-DUPLEXGEN-DEVELOPMENT-20260904-v1:` concatenated with the original public `example_id`, rendered in uppercase hex. Within each scenario, the four lexicographically first released training hashes form validation. This fixed rule yields 1142 fit and 253 validation positions. The test set was repeatedly examined during development and must not be interpreted as independent confirmation.

## Scoring and manuscript mapping

Targets come from original integer action counts divided by their sum, rather than rounded released probability fields. KL uses natural logarithms and clipping at `1e-12`; Brier sums squared differences over three actions. Each score is averaged first over positions within a dialogue, then equally over scenarios and seed-specific scores. Each test scenario has 50 dialogues, so the scenario-equal average is also the dialogue-equal average. No majority-label conversion is made.

The script reproduces the common-split raw/SLTS means in Table 2 and the SLTS/affine means in Table 11, plus the final sensitivity contrasts. `NATIVE_1` is one epoch; `NATIVE_SELECTED` is epoch 2; `LPFT_SELECTED` is epoch 1. `HEAD_L2_0` and `HEAD_L2_1` use validation-selected step 36; `FULL` refers to complete step 72. For these two head-only controls, `0` omits the explicit readout penalty and `1` retains it. `AFFINE` denotes calibration on raw logits, not canonical log-probability Dirichlet calibration. These maps and checkpoint choices were fitted or selected on validation before the final scoring stage.

Positive contrasts favor the named target. The 2000 paired bootstrap draws resample 50 dialogues within each of the six scenarios using NumPy `default_rng(20260906)`. Seed-specific differences are averaged before resampling. Intervals are conditional on the exposed dialogue sample and retained training seeds; they do not adjust for exploratory selection or estimate seed-population uncertainty.

The key affine-calibration contrast is frozen versus LP-FT: KL gain approximately `0.001547421`, 95% interval `[-0.000142812, 0.003092012]`. The corresponding Brier gain is approximately `0.001383809`, interval `[0.000369149, 0.002322942]`. Thus the KL interval crosses zero while the Brier interval does not. The script retains both metrics and all outcomes.

## Availability boundary

This is an anonymous local archive prepared to accompany the paper through the submission system. It is not a hosted public repository. To make it accessible to reviewers, attach `rtca_anonymous_supplement.zip` with the manuscript in the venue's supplementary-material field. No contact details, local filesystem paths, model checkpoints, dialogue payloads or original vote labels are included. AI assistance with implementation and writing is disclosed in the manuscript.
