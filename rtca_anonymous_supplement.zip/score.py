"""Rescore saved predictions against separately obtained, pinned DuplexGen votes.

Requires only Python 3.10+ and NumPy. No training, model selection or GPU use.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import urllib.request

import numpy as np

ROOT = Path(__file__).resolve().parent
SCENARIOS = ['TEA', 'PLN', 'INT', 'NEG', 'PER', 'SOC']
ACTIONS = ['silent', 'backchannel', 'take_floor']
SALT = 'RTCA-DUPLEXGEN-DEVELOPMENT-20260904-v1:'
PAIRS = [
    ('FROZEN_SLTS', 'STRUCTURE_SLTS'),
    ('FROZEN_AFFINE', 'STRUCTURE_AFFINE'),
    ('FROZEN_AFFINE', 'NATIVE_SELECTED_AFFINE'),
    ('FROZEN_AFFINE', 'LPFT_SELECTED_AFFINE'),
    ('HEAD_L2_0_SLTS', 'FROZEN_SLTS'),
    ('HEAD_L2_1_SLTS', 'FROZEN_SLTS'),
    ('HEAD_L2_0_FULL_RAW', 'LPFT_SELECTED_RAW'),
    ('HEAD_L2_0_FULL_SLTS', 'LPFT_SELECTED_SLTS'),
    ('HEAD_L2_1_FULL_SLTS', 'HEAD_L2_0_FULL_SLTS'),
]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_csv(name):
    with (ROOT / name).open(encoding='utf-8', newline='') as stream:
        return list(csv.DictReader(stream))


def load_targets(data_dir):
    """Read original counts, verify file hashes and reconstruct the exact split."""
    targets, dialogues = {}, {}
    for source in json.loads((ROOT / 'sources.json').read_text()):
        scenario, split = source['scenario'], source['split']
        if data_dir is None:
            with urllib.request.urlopen(source['url'], timeout=45) as response:
                body = response.read()
        else:
            body = (data_dir / 'annotations' / scenario / (split + '.jsonl')).read_bytes()
        require(hashlib.sha256(body).hexdigest().upper() == source['sha256'],
                'Public source hash mismatch: ' + scenario + '/' + split)
        for line in body.decode('utf-8').splitlines():
            if not line.strip():
                continue
            obj = json.loads(line)
            group = hashlib.sha256((SALT + obj['example_id']).encode()).hexdigest().upper()
            require(group not in dialogues, 'Duplicate dialogue hash')
            count = 0
            for turn_index, turn in enumerate(obj['history']):
                for boundary in turn.get('boundaries') or []:
                    word = boundary['word_index']
                    require(turn['role'] == 'user' and 0 <= word < len(turn['content'].split()),
                            'Invalid boundary')
                    votes = np.array([boundary['counts'].get(a, 0) for a in ACTIONS], dtype=float)
                    require((votes >= 0).all() and votes.sum() > 0
                            and votes.sum() == boundary['total_count'], 'Invalid vote counts')
                    if split == 'test':
                        key = (group, turn_index, word)
                        require(key not in targets, 'Duplicate test position')
                        targets[key] = (scenario, votes / votes.sum())
                    count += 1
            dialogues[group] = (scenario, split, count)
    manifest = read_csv('split_manifest.csv')
    require(len(manifest) == len(dialogues) == 420, 'Dialogue count mismatch')
    require({r['dialogue_hash'] for r in manifest} == set(dialogues), 'Split coverage mismatch')
    held = set()
    for scenario in SCENARIOS:
        train = sorted(g for g, (s, split, _) in dialogues.items()
                       if s == scenario and split == 'train')
        require(len(train) == 20, 'Unexpected training dialogue count')
        held.update(train[:4])
    totals = {'fit': 0, 'validation': 0, 'exposed_test': 0}
    for row in manifest:
        group = row['dialogue_hash']
        scenario, split, count = dialogues[group]
        partition = 'exposed_test' if split == 'test' else ('validation' if group in held else 'fit')
        require((row['scenario'], row['release_split'], int(row['positions']), row['analysis_split'])
                == (scenario, split, count, partition), 'Split manifest mismatch')
        totals[partition] += count
    require(totals == {'fit': 1142, 'validation': 253, 'exposed_test': 3244}, 'Position count mismatch')
    rows = read_csv('positions.csv')
    require([int(r['row']) for r in rows] == list(range(3244)), 'Prediction row index mismatch')
    keys = [(r['dialogue_hash'], int(r['turn_index']), int(r['word_index'])) for r in rows]
    require(len(set(keys)) == 3244 and set(keys) == set(targets), 'Prediction alignment mismatch')
    require(all(targets[k][0] == r['scenario'] for k, r in zip(keys, rows)), 'Scenario mismatch')
    return (np.array([targets[k][1] for k in keys]),
            np.array([r['dialogue_hash'] for r in rows]),
            np.array([SCENARIOS.index(r['scenario']) for r in rows]))


def score(targets, groups, scenarios):
    saved = np.load(ROOT / 'predictions.npz', allow_pickle=False)
    q, names = saved['q'], saved['models'].tolist()
    require(q.shape == (3244, 28, 3, 3), 'Prediction shape mismatch')
    require(np.isfinite(q).all() and (q >= 0).all()
            and np.allclose(q.sum(-1), 1, atol=1e-12, rtol=0), 'Invalid probabilities')
    require(saved['seeds'].tolist() == [20260906, 20260907, 20260908], 'Seed mismatch')
    p = targets[:, None, None, :]
    slot_kl = np.sum(p * (np.log(np.clip(p, 1e-12, 1)) - np.log(np.clip(q, 1e-12, 1))), axis=-1)
    slot_brier = np.sum((p - q) ** 2, axis=-1)
    unique = np.unique(groups)
    gkl = np.array([slot_kl[groups == g].mean(0) for g in unique])
    gb = np.array([slot_brier[groups == g].mean(0) for g in unique])
    gs = np.array([scenarios[groups == g][0] for g in unique])
    require(len(unique) == 300 and all((gs == s).sum() == 50 for s in range(6)), 'Test balance mismatch')
    rng = np.random.default_rng(20260906)
    draws = np.concatenate([rng.choice(np.flatnonzero(gs == s), (2000, 50), replace=True)
                            for s in range(6)], axis=1)
    result = {'models': names, 'kl': gkl.mean((0, 2)).tolist(), 'brier': gb.mean((0, 2)).tolist(),
              'kl_per_seed': gkl.mean(0).tolist(), 'brier_per_seed': gb.mean(0).tolist(), 'contrasts': []}
    for target, baseline in PAIRS:
        i, j = names.index(target), names.index(baseline)
        item = {'target': target, 'baseline': baseline, 'positive_favors_target': True}
        for metric, values in [('kl', gkl), ('brier', gb)]:
            differences = values[:, j] - values[:, i]
            delta = differences.mean(1)
            item[metric + '_gain'] = float(delta.mean())
            item[metric + '_ci95'] = np.quantile(delta[draws].mean(1), [.025, .975]).tolist()
            item[metric + '_seed_gains'] = differences.mean(0).tolist()
        result['contrasts'].append(item)
    return result


def compare(actual, expected):
    if isinstance(actual, dict):
        return max(compare(v, expected[k]) for k, v in actual.items())
    if isinstance(actual, list):
        require(len(actual) == len(expected), 'Result length mismatch')
        return max((compare(a, b) for a, b in zip(actual, expected)), default=0.)
    if isinstance(actual, (int, float)) and not isinstance(actual, bool):
        return abs(actual - expected)
    require(actual == expected, 'Result metadata mismatch')
    return 0.


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sources = parser.add_mutually_exclusive_group(required=True)
    sources.add_argument('--fetch', action='store_true', help='Read pinned public annotations into memory; do not save them')
    sources.add_argument('--data-dir', type=Path, help='Local dataset root containing annotations/SCENARIO/{train,test}.jsonl')
    parser.add_argument('--output', type=Path, default=Path('rescored.json'))
    args = parser.parse_args()
    require(not args.output.exists(), 'Output already exists; choose a new --output path')
    for name, digest in json.loads((ROOT / 'FILES_SHA256.json').read_text()).items():
        require(hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, 'Archive integrity mismatch: ' + name)
    result = score(*load_targets(args.data_dir))
    discrepancy = compare(result, json.loads((ROOT / 'expected_results.json').read_text()))
    require(discrepancy < 5e-12, 'Saved-result comparison exceeded tolerance')
    result['verification'] = {'max_absolute_difference': discrepancy, 'test_previously_exposed': True,
                              'scope': 'Rescoring saved predictions; no independent training or model-selection reproduction'}
    args.output.write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(f'PASS: 420 dialogue assignments, 3244 test positions, 28 outputs; max error {discrepancy:.3g}')


if __name__ == '__main__':
    main()
